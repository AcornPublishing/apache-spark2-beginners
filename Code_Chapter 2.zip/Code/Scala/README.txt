IMPORTANT: In the scripts mentioned below, wherever there is SPARK_HOME settings are there, change the directory to your own directory for these scripts to work. Also note that the config.sbt file captures all the required dependencies. The Spark version has to be changed as and when new Spark 2.x versions are available.
The code can be compiled using the following wrapper script
./compile.sh

The following script can be used to run the application in the local mode. Change the submit.sh file to suite your requirements
./submit.sh com.packtpub.sfb.StarterApps
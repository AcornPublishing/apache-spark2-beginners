The code can be compiled and run from R Studio by opening the R file from the R Studio. The data files are located in the same directory. In the code make hte following changes
1) In the beginning, point to the right directory where Spark is installed
2) Make sure that the data file paths are correctly given in the script. It is better to give absolute path.
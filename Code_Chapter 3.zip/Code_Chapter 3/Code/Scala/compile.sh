#!/bin/bash
sbt compile
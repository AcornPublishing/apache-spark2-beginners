IMPORTANT: Make sure that the $SPARK_HOME environment variables are set properly pointing to your Spark installations

The code can be compiled using the following wrapper script. Instead of this script, you may also use just the `sbt compile` command
./compile.sh

The following script can be used to run the application in the local mode. Change the submit.sh file to suite your requirements
./submit.sh com.packtpub.sfb.MLApps

